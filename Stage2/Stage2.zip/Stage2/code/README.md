# Source Code Files

### Steps:
#### Data cleaning 
    - scrip_to_clean_data
#### Data Tagging 
    - entity_tagging.py
#### Feature Extraction
    - feature_extraction.py 
#### Traning and cross validation
    - learning.py
        - read feature list & class list
        - CV scores from Classifiers
        - Linear Regression CV
### Testing 
     - testing.py
