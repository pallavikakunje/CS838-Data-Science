# Review Documents

###Marked Documents:
####Positive tags:
* We have marked all game names from the game reviews as positive 
* The tag for game name is <+++> GAME NAME </+++>

####Negative tags:
* We have marked all the words and phrases with first letter capital words as negative tag for game name
* The tag for game name is <---> PHRASE </--->

